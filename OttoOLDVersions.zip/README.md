# 3D printing files


* Recommended to use a `FDM 3D printer with PLA material`
* No need of supports or rafts at all.
* Resolution: `0.28mm`
* Fill density: 15%
* At least 3 perimeters


## Notes on changes in 3D print versions

V12
Released 23April , 2021

Modular xpansions capability, accessories, better place for the shield and toggle switch

​

V11
Released 1 Feb, 2021

* OttoDIY\_body\_V10.stl
  * Added snap for the switch
  * Simplified ribs for booster
  * Reduced the ribs thickness
  * Snaps thicker
* OttoDIY\_head\_V11.stl
  * Added frame for the ultrasonic sensor
  * Raise the holes for the ultrasonic sensor
  * Deleted side slots
* OttoDIY\_leg\_V11.stl
  * Adjusted tolerances
  * Added chamfer in the corners
* OttoDIY\_Foot\_V11.stl
  * Created Left and right version in order to have better pivot and assembly
  * Arm key assembly for the servo simplified

V10

Released 7 May, 2020

* OttoDIY\_body\_V10.stl
  * added 4 screw holes at bottom inside and access hole in rear for addition of battery charger + power booster with switch \(https://www.ottodiy.com/store#!/battery-charger-power-booster-with-switch/p/185515272/category=0\)
  * ottodiy.com mark moved up on back of body \(adjustment for access hole for battery charger\)
  * removed v9 mark frpm inside body center
  * added v10 mark to front\(left\) inside of body
  * indent groves added to front and back
* OttoDIY\_foot\_V10.stl
  * ottodiy.com moved from bottom of foot to top of foot
  * small design change on rear of foot, from straight edge to small triange indent
* OttoDIY\_head\_V10.stl
  * change in access hole shape for mini USB connector type B
  * small change in shape \(rounded the corners\) of indents above the head tabs
  * moved engrave of ottodiy.com from inside top of head to outside back of head
  * added v10 to inside top of head
  * moved indent for touch sensor to left\(rear\) corner inside the head
* OttoDIY\_leg\_V10.stl
  * from side view shape of access to inside leg changed.  Change to soft line D-shape.
    ```
    UPDATE as of May 21 : Reverted back to hard D shape to make easier for 3D printer.
    ```
  * from front view bottom, outdent circle design has changed.

Previod versions are not compatible in size so if you choose to make them they will not match with the latest modular expansions

Find more in http://builders.ottodiy.com/
Happy robot building!